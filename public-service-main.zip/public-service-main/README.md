# public-service
Internship project.
Hellojava is a main class,
Hello class for insert new job,
Emp class for job allocation,
Display class for displayong job details,
Empavai class for display employees,
Empp class for insert new employee.
